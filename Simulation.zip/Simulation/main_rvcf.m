%% Amplitude Magnification
% Author: Wenbo Li;
% Email: wuhenyisheng@tamu.edu;
% Date: Aug, 25, 2024;
% Instruction: This program is used to verify the influence of the angular 
% frequency in complex plane on vibration amplitude.
%--------------------------------------------------------------------------
%% The initializaion of parameters
clc
clear all

i_o = 2;
i_m = 2;

m1 = 2; % Mass
m2 = 0.5;
k1 = 600; % Stiffness
k2 = 3000;
% w_n = sqrt(k/m); % Natural frequency

c1 = 4; % Damping coefficient
c2 = 0.4;
F_0 = 1; % Initial amplitude of force F

% Gamma =  c/(2*w_n*m);

a = 0.98; % Eccentricity

%% Matrix construction
M = [m1,  0  ;
     0 ,  m2 ];

C = [c1 + c2,   -c2   ;
     -c2     ,   c2  ];

K = [k1 + k2,   -k2   ;
     -k2     ,   k2  ];


[Phi, omega] = polyeig(K, 1i*C, -M);  


pos = find(real(omega)>0);       
omega_pos = omega(pos);          
Phi_pos   = Phi(:,pos);          


omega_d = abs(real(omega_pos));   


[~, idx]     = sort(omega_d);    
omega_modes  = omega_pos(idx);   
Phi_modes    = Phi_pos(:,idx);   



[omega_n, zeta] = ComputeModalProperties(M, C, K);

w_n = omega_n(i_o);
Gamma = zeta(i_o);

target = omega_n(1)*zeta(1)/(omega_n(2)*zeta(2))
%% The construction of F vector

T_c = 20;
Max = 1;


w_min = 70;
delta_w = 0.01;
w_max = 100;
i_2 = 0;


for delta_wi = [Gamma*w_n, Gamma*w_n-0.5, 0,Gamma*w_n-1, Gamma*w_n-1.2]%[Gamma*w_n-1.5, -0.6:0.2:0.6, Gamma*w_n]
    A_max_new = zeros;
    i_1 = 0;
    i_2 = i_2 +1;
for w_1 = w_min:delta_w:w_max

    i_1 = i_1+1

    % u_1 = zeros(2,:);
    % v_1 = zeros(2,:);
    alpha = zeros;

for i0 = 1:Max
    
%     t_min = T_c*(i0-1);
%     t_max = T_c*i0;
    t_min = 0;
    t_max = T_c;
    dt = 1e-4;
    t = t_min: dt : t_max;
    n = length(t);

    w_c = 2*pi/T_c;

for i = 1:n
%     w_r_1(i) = ((-Gamma*w_n*sin(w_c*t(i)))/a)*(sqrt((1-a^2)/(1-a^2*cos(w_c*t(i))^2)))+w_n*sqrt(1-Gamma^2);
%     w_i_1(i) = ((Gamma*w_n*cos(w_c*t(i)))/a)*(sqrt((1-a^2)/(1-a^2*cos(w_c*t(i))^2)));
%     w_r_1(i) = ((-Gamma*w_n*sin(w_c*t(i)-pi/2))/a)*(sqrt((1-a^2)/(1-a^2*cos(w_c*t(i)-pi/2)^2)))+w_n*sqrt(1-Gamma^2);
    w_r_1(i) = w_1;
    w_i_1(i) = Gamma*w_n-delta_wi;
     % w_i_1(i) = 0;
    F(1,i) = 0;
     F(2,i) = F_0*exp(-w_i_1(i)*t(i))*sin(w_r_1(i)*t(i));
%      F(i) = F_0*cos(w_1*t(i));
    alpha(i) = exp(w_i_1(i)*t(i));
end

%% Solution by Newmark-beta method
    u0 = [0 0]';
    v0 = [0 0]';

[u_1,~,~] = CentralDifferenceMethod(M, C, K, u0, v0, F, dt, t);
u_1_new = alpha.*u_1(i_m,:);

    u = u_1;
    u_new = u_1_new;
end
%% Plot spctrum by FFT

Fs = 1/dt;

if delta_wi<=0
    [A_max_new(i_1), P1] = FFT(u_new, Fs);
else
    A_max_new(i_1) = max(u_new(19e4:end))-min(u_new(19e4:end));
end



% figure()
% t_total = 0:dt:T_c*Max;
% plot(t_total,u);
% ylabel('Displacement','FontSize',14, 'Interpreter','latex');
% xlabel('Time [s]','FontSize',14, 'Interpreter','latex');
% 
end

w_r_0 = w_n*sqrt(1-Gamma^2)
w_i_0 = Gamma*w_n


[A_max_max, p_max] = max(A_max_new)
Plot_A_max_new(i_2,:) = A_max_new/A_max_max;

w_new = w_min:delta_w:w_max;

w_real_max = w_new(p_max);

Half_A_max_new(i_2,:) = abs(Plot_A_max_new(i_2,:)-0.707);
[~,p_half_left] = min(Half_A_max_new(i_2,1:p_max));
[~,p_half_right] = min(Half_A_max_new(i_2,p_max:end));
p_half_right = p_half_right + p_max - 1;

q(i_2) = w_real_max/(w_new(p_half_right)-w_new(p_half_left));
w_i_new(i_2) = Gamma*w_n-delta_wi;
% figure()
% plot(w_new, A_max)
% ylabel('Amplitude', 'Interpreter','latex');
% xlabel(' $\omega_r$  [rad/s]', 'Interpreter','latex');
% set(gca,'FontSize',14);
% 
% figure()
% plot(w_new, A_max_new)
% ylabel('Amplitude', 'Interpreter','latex');
% xlabel(' $\omega_r$  [rad/s]', 'Interpreter','latex');
% set(gca,'FontSize',14);
end

w_new = w_min:delta_w:w_max;


figure()
plot(w_new, Plot_A_max_new,'LineWidth',1);
ylabel('$\beta$ normalized', 'Interpreter','latex');
xlabel(' $\omega_r$  [rad/s]', 'Interpreter','latex');
set(gca,'FontSize',14);
xlim([5 100]);
legend('$\omega_i=0$ rad/s','$\omega_i=0.5$ rad/s','$\omega_i=0.7869$ rad/s','$\omega_i=1$ rad/s','$\omega_i=1.2$ rad/s','Interpreter','latex','FontSize',14)


% figure()
% plot(w_new, Plot_A_max_new(1,:),'LineWidth',1,'Color',[77 190 238]/255);
% ylabel('$\beta$ normalized', 'Interpreter','latex');
% xlabel(' $\omega_r$  [rad/s]', 'Interpreter','latex');
% set(gca,'FontSize',14);
% xlim([10 200]);
% 
% hold on
% plot(w_new, Plot_A_max_new(2,:),'LineWidth',1,'Color','#7BA23F');
% plot(w_new, Plot_A_max_new(3,:),'LineWidth',1,'Color','#CC543A');
% plot(w_new, Plot_A_max_new(4,:),'LineWidth',1,'Color','#A8497A');
% plot(w_new, Plot_A_max_new(5,:),'LineWidth',1,'Color','#268785');
% plot(w_new, Plot_A_max_new(6,:),'LineWidth',1,'Color','#86473F');
% 
% legend('$\omega_i=0$','$\omega_i=6$','$\omega_i=7$','$\omega_i=8$','$\omega_i=9$','$\omega_i=10$','Interpreter','latex','FontSize',14)

figure()
% plot(w_i_new, q,'LineWidth',1,'Color','#CC543A');
plot(w_i_new, q,'-x','LineWidth',1.5,'Color','#CC543A','MarkerSize',10);
ylabel('$Q_{\mathrm{eff}}$', 'Interpreter','latex');
xlabel(' $\omega_i$  [rad/s]', 'Interpreter','latex');
% set(gca,'FontSize',14,'XTick',0:1:10);
set(gca,'FontSize',14);