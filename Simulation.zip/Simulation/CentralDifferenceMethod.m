function [u, v, a] = CentralDifferenceMethod(M, C, K, u0, v0, F, dt, t)

    ndof   = length(u0);
    nSteps = length(t);
    
    u = zeros(ndof, nSteps);
    v = zeros(ndof, nSteps);
    a = zeros(ndof, nSteps);
    
    u(:,1) = u0;
    
    a(:,1) = M \ (F(:,1) - C*v0 - K*u0);
    
    u(:,2) = u(:,1) + dt*v0 + 0.5*dt^2*a(:,1);

    A = M + (C*dt)/2;
    A_inv = inv(A);
    

    for i = 2:(nSteps-1)
        u(:, i+1) = A_inv * ( dt^2*( F(:,i) - K*u(:,i) ) + 2*M*u(:,i) - M*u(:,i-1) + (C*dt)/2 * u(:,i-1) );
    end
    
    
    for i = 2:(nSteps-1)
        v(:, i) = ( u(:, i+1) - u(:, i-1) ) / (2*dt);
        a(:, i) = ( u(:, i+1) - 2*u(:, i) + u(:, i-1) ) / (dt^2);
    end

    v(:, nSteps) = ( u(:, nSteps) - u(:, nSteps-1) ) / dt;
    a(:, nSteps) = ( u(:, nSteps) - 2*u(:, nSteps-1) + u(:, nSteps-2) ) / (dt^2);
    
    v(:,1) = v0;
end
