clc
clear all

%% Data Loading
mat_file_path = 'G:\My Drive\PhD\Papers\Paper2\Code\Signal1_V.mat';
data = load(mat_file_path);

trF = data.frc;
trV = data.vel;
trt = data.t;

%% Parameter Setting
num_start = 500017;
num_length = 4.5e5;

omega_i = 81.6;
t_p = 0.02;

%% Displacement
numCells = 1;
displacements = cell(numCells, 1);
displacements_new = cell(numCells, 1);
frequencies = cell(numCells, 1);
force_fft = cell(numCells, 1);
disp_fft = cell(numCells, 1);
disp_new_fft = cell(numCells, 1);
AF = cell(numCells, 1);
AF_new = cell(numCells, 1);
AF_o = cell(numCells, 1);
F_o_fft = cell(numCells, 1);
fc = [88 89 90];

figure;
for i = 1:numCells
    time_F = trt;
    force = trF;
    time_V = trt;
    velocity = trV;

    max_length_F = min(num_length, length(force) - num_start + 1);
    max_length_V = min(num_length, length(velocity) - num_start + 1);

    time_F = time_F(num_start:num_start+max_length_F-1);
    time_F = time_F - time_F(1);
    force_0 = force(num_start:num_start+max_length_F-1);
    time_V = time_V(num_start:num_start+max_length_V-1);
    time_V = time_V - time_V(1);
    velocity = velocity(num_start:num_start+max_length_V-1);

    displacement = cumtrapz(time_V, velocity);
    displacements{i} = [time_V, displacement];
    
    F_o = zeros(length(time_F),1);
    for i3 = 1:length(time_F)
        F_o(i3) = sin(2*pi*fc(i)/96*time_F(i3))*sin(2*pi*fc(i)*time_F(i3));
    end

% Target Displacement
    alpha = zeros(length(time_V),1);
    for i1 = 1:1:length(time_V)
        alpha(i1) = exp(omega_i*time_V(i1));
    end
    
    N_displacement = length(displacement);
    
    for i6 = 1:N_displacement
        if time_V(i6) <= t_p
            displacement_new(i6) = displacement(i6)*alpha(i6);
        else
            displacement_new(i6) = displacement(i6);
        end
    end

% Trend Term Removal    
    window_size = 2001;
    poly_order = 2;

    displacement_trend = sgolayfilt(displacement_new, poly_order, window_size);

    displacement_detrended = displacement_new - displacement_trend;

    displacement_new = displacement_detrended;

    displacements_new{i} = [time_V, displacement_new'];
    
   
    N_force = length(force_0);

    for i5 = 1:N_force
        if time_F(i5) <= t_p
            force_1(i5) = force_0(i5)*alpha(i5);
        else
            force_1(i5) = force_0(i5);
        end
    end
     force = force_1;

       force = force_1;
    window_size = 2001;
    poly_order = 2;

    force_trend = sgolayfilt(force, poly_order, window_size);

    force_detrended = force - force_trend;

    force = force_detrended;
    
    
%% FFT
    Fs = 1 / mean(diff(time_V));
    N = length(displacement);
    f = (0:N-1) * (Fs / N);

    Y_force = fft(force - mean(force));  
    Y_force_o = fft(F_o - mean(F_o));
    Y_disp = fft(displacement - mean(displacement));
    Y_disp_new = fft(displacement_new - mean(displacement_new));

    N = length(displacement);
    f = (0:N/2-1) * (Fs / N);

    A_F = zeros(length(f),1);
    A_F_new = zeros(length(f),1);
    A_F_o = zeros(length(f),1);
    for i2 = 1:1:length(f)
        A_F(i2) = abs(Y_disp(i2))/abs(Y_force(i2));
        A_F_new(i2) = abs(Y_disp_new(i2))/abs(Y_force(i2));
        A_F_o(i2) = abs(Y_disp(i2))/abs(Y_force_o(i2));
    end

    force_fft{i} = abs(Y_force(1:N/2)) / (N/2);
    F_o_fft{i} = abs(Y_force_o(1:N/2)) / (N/2);
    AF_o{i} = A_F_o;
    disp_fft{i} = abs(Y_disp(1:N/2)) / (N/2);
    disp_new_fft{i} = abs(Y_disp_new(1:N/2)) / (N/2);
    AF{i} = A_F;
    AF_new {i} = A_F_new;

    frequencies{i} = f;

    x_range = [500 700];
    
%     subplot(numCells, 3, 3*i-2);
%     plot(f, force_fft{i});
%     title(['Force FFT']);
%     xlabel('Frequency (Hz)');
%     ylabel('Magnitude');
%     xlim(x_range);
% 
%     subplot(numCells, 3, 3*i-1);
%     plot(f, disp_fft{i});
%     title(['Dis FFT']);
%     xlabel('Frequency (Hz)');
%     ylabel('Magnitude');
%     xlim(x_range);
% 
%     subplot(numCells, 3, 3*i);
%     plot(f, disp_new_fft{i});
%     title(['Target dis FFT']);
%     xlabel('Frequency (Hz)');
%     ylabel('Magnitude');
%     xlim(x_range);

end

figure()
    plot(2*pi*f, AF_new{1}/max(AF_new{1}(2500:7500)),'LineWidth',1);
    xlabel(' Frequency [rad/s]', 'Interpreter','latex');
    ylabel(' $\beta$', 'Interpreter','latex');
    xlim([3000 3600]);
    set(gca,'FontSize',14);

data_A = AF_new{1}/max(AF_new{1}(2500:7500)); 
data_f = f;
save('35.mat', 'data_f','data_A'); 
